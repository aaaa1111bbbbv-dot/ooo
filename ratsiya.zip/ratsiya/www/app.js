/* RATSIYA PRO v2 — himoyalangan WebRTC walkie-talkie (PeerJS) */
const SECRET_APP_PREFIX = "UZTAC_PRIVATE_V2_";
const $ = (id) => document.getElementById(id);

// ---------- Holat ----------
let peer = null, hostConn = null;
let isConnected = false, isHost = false;
let currentChannel = '400', roomKey = '';
let localRawStream = null, processedStream = null;
let audioContext = null, micGainNode = null, analyserNode = null;
let boostLevel = 2.2;
let isTransmitting = false, isMicLocked = false, isLoopbackTest = false;
let activeIncomingCount = 0, wakeLock = null, loopbackAudioEl = null;
const peers = {};          // { id: { call, conn } }
const remoteGains = {};    // { id: GainNode }
const rxTimers = {};       // { id: intervalId }

// ---------- DOM ----------
const pttBtn = $('ptt-button'), pttMain = $('ptt-main-text'), pttSub = $('ptt-sub-text');
const ledTx = $('led-tx'), ledRx = $('led-rx');
const lcdStatus = $('lcd-status-text'), lcdChannel = $('lcd-channel-display'), lcdFreq = $('lcd-freq-display');
const lcdLock = $('lcd-lock-icon'), connBadge = $('conn-badge'), roleBadge = $('role-badge');
const peerCountEl = $('peer-count'), connectBtn = $('connect-btn');
const channelInput = $('channel-input'), passwordInput = $('password-input');
const toastBar = $('toast-bar'), vuLabel = $('vu-label');

const vuSegs = [];
for (let i = 0; i < 16; i++) {
  const d = document.createElement('div');
  $('vu-meter').appendChild(d);
  vuSegs.push(d);
}

// ---------- UI yordamchilar ----------
const setToast = (m) => { toastBar.textContent = m; };
function showAlert(title, msg) {
  $('alert-title').textContent = title;
  $('alert-message').textContent = msg;
  $('alert-modal').classList.remove('hidden');
}
function closeAlertModal() { $('alert-modal').classList.add('hidden'); }
function toggleHelpModal(show) { $('help-modal').classList.toggle('hidden', !show); }
function updateSignalBars(level) {
  [...$('signal-bars').children].forEach((b, i) => { b.style.background = i < level ? '#86efac' : '#2f4532'; });
}
function togglePasswordVisibility() {
  const show = passwordInput.type === 'password';
  passwordInput.type = show ? 'text' : 'password';
  $('toggle-pass-btn').textContent = show ? '🙈' : '👁️';
}

// ---------- Ovoz effektlari ----------
function ensureAudioContext() {
  if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
  if (audioContext.state === 'suspended') audioContext.resume();
}
function tone(freq, start, dur, type = 'sine', vol = 0.2, freqEnd) {
  const osc = audioContext.createOscillator(), g = audioContext.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, start);
  if (freqEnd) osc.frequency.exponentialRampToValueAtTime(freqEnd, start + dur);
  g.gain.setValueAtTime(vol, start);
  g.gain.exponentialRampToValueAtTime(0.001, start + dur);
  osc.connect(g); g.connect(audioContext.destination);
  osc.start(start); osc.stop(start + dur + 0.005);
}
function playTxStartBeep() {
  try { ensureAudioContext(); tone(1100, audioContext.currentTime, 0.07, 'sine', 0.18, 1450); } catch (e) {}
}
function playRogerBeep() {
  try {
    ensureAudioContext();
    const t = audioContext.currentTime;
    tone(1568, t, 0.06, 'triangle', 0.22);
    tone(2093, t + 0.065, 0.06, 'triangle', 0.22);
  } catch (e) {}
}
function playSquelchTail() {
  try {
    ensureAudioContext();
    const n = Math.floor(audioContext.sampleRate * 0.09);
    const buf = audioContext.createBuffer(1, n, audioContext.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (n * 0.4));
    const src = audioContext.createBufferSource(); src.buffer = buf;
    const f = audioContext.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1800;
    const g = audioContext.createGain(); g.gain.value = 0.15;
    src.connect(f); f.connect(g); g.connect(audioContext.destination);
    src.start();
  } catch (e) {}
}

// ---------- Mikrofon ----------
async function initMicrophone() {
  if (processedStream && localRawStream && localRawStream.active) return true;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showAlert("Qo'llab-quvvatlanmaydi", "Mikrofon mavjud emas yoki sahifa xavfsiz (HTTPS) ulanishda ochilmagan.");
    return false;
  }
  try {
    ensureAudioContext();
    localRawStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: false
    });
    const source = audioContext.createMediaStreamSource(localRawStream);
    micGainNode = audioContext.createGain();
    micGainNode.gain.value = boostLevel;
    analyserNode = audioContext.createAnalyser();
    analyserNode.fftSize = 64;
    const dest = audioContext.createMediaStreamDestination();
    source.connect(micGainNode);
    micGainNode.connect(analyserNode);
    micGainNode.connect(dest);
    processedStream = dest.stream;
    setMicrophoneEnabled(false);
    startVuLoop();
    return true;
  } catch (err) {
    console.error(err);
    showAlert("Mikrofonga ruxsat berilmadi!", "Telefon sozlamalari → Ilovalar → Ratsiya Pro → Ruxsatlar bo'limida Mikrofonni yoqing.");
    return false;
  }
}
function setMicrophoneEnabled(on) {
  [localRawStream, processedStream].forEach(s => s && s.getAudioTracks().forEach(t => { t.enabled = on; }));
}

let vuStarted = false;
function startVuLoop() {
  if (vuStarted) return;
  vuStarted = true;
  const data = new Uint8Array(analyserNode.frequencyBinCount);
  const paint = (n, colorFn) => vuSegs.forEach((s, i) => { s.style.background = i < n ? colorFn(i) : '#2f4532'; });
  (function loop() {
    if (isTransmitting || isLoopbackTest) {
      analyserNode.getByteFrequencyData(data);
      const avg = data.reduce((a, b) => a + b, 0) / data.length;
      paint(Math.min(16, Math.round(avg / 140 * 16)), i => i > 12 ? '#ef4444' : i > 9 ? '#f59e0b' : '#86efac');
    } else if (activeIncomingCount > 0) {
      paint(Math.floor(Math.random() * 10) + 4, () => '#4ade80');
    } else paint(0);
    requestAnimationFrame(loop);
  })();
}

// ---------- Kanal / xona kaliti ----------
function buildSecureRoomKey(channel, password) {
  const raw = `${SECRET_APP_PREFIX}CH:${channel}|PWD:${password}`;
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < raw.length; i++) {
    const c = raw.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 2654435761);
    h2 = Math.imul(h2 ^ c, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  const hex = (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36).toUpperCase();
  return `${SECRET_APP_PREFIX}${channel}_${hex}`;
}

function selectPreset(code, freq) {
  if (isConnected) { setToast("Kanalni o'zgartirish uchun avval aloqani uzing!"); return; }
  channelInput.value = code;
  lcdChannel.textContent = `CH-${code}`;
  lcdFreq.textContent = freq;
  document.querySelectorAll('[id^="btn-ch-"]').forEach(b => b.classList.remove('active'));
  const b = $(`btn-ch-${code}`);
  if (b) b.classList.add('active');
}

channelInput.addEventListener('input', (e) => {
  const v = e.target.value.trim().toUpperCase();
  lcdChannel.textContent = v ? (v.length <= 3 ? `CH-${v}` : v) : 'CH-00';
  let h = 0; for (const ch of v) h += ch.charCodeAt(0);
  lcdFreq.textContent = `446.${String((h % 899) + 100).padStart(3, '0')}`;
});

// ---------- Ulanish ----------
async function toggleConnection() {
  if (isConnected) { disconnectRadio(); return; }

  const code = channelInput.value.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
  const pass = passwordInput.value.trim();
  if (!code) return showAlert("Kanal kiritilmadi", "Kanal raqami yoki nomini kiriting (masalan: 400).");
  if (pass.length < 3) return showAlert("Parol kiritilmadi", "Kamida 3 belgidan iborat parol kiriting.");

  if (isLoopbackTest) await toggleLoopbackTest();
  if (!(await initMicrophone())) return;

  currentChannel = code;
  roomKey = buildSecureRoomKey(code, pass);
  connectBtn.disabled = true;
  connectBtn.textContent = "ULANMOQDA...";
  lcdStatus.textContent = "SHIFRLANGAN KANAL QIDIRILMOQDA...";
  setToast("Himoyalangan tarmoqqa ulanilmoqda...");
  requestWakeLock();
  tryConnectAsHost(`${roomKey}-HOST`);
}

function tryConnectAsHost(hostId) {
  cleanupPeer();
  const p = new Peer(hostId, { debug: 0 });
  peer = p;
  setupPeerListeners(p);

  p.on('open', () => {
    isHost = true; isConnected = true;
    onConnectedUI("HOST • YOPIQ");
    setToast(`Kanal ${currentChannel} ochildi. Guruhdoshlarni kuting.`);
  });
  p.on('error', (err) => {
    if (err.type === 'unavailable-id') {
      p.destroy();
      connectAsClient(hostId);
    } else {
      console.error(err);
      disconnectRadio();
      setToast("Tarmoq xatosi! Internetni tekshiring.");
    }
  });
}

function connectAsClient(hostId) {
  const clientId = `${roomKey}-M-${Math.random().toString(36).substring(2, 8)}`;
  const p = new Peer(clientId, { debug: 0 });
  peer = p;
  setupPeerListeners(p);

  p.on('open', () => {
    isHost = false; isConnected = true;
    onConnectedUI("MIJOZ • YOPIQ");

    const conn = p.connect(hostId, { reliable: true });
    hostConn = conn;
    conn.on('open', () => {
      peers[hostId] = peers[hostId] || {};
      peers[hostId].conn = conn;
      setToast(`Kanal ${currentChannel} ga ulandingiz!`);
      callRemotePeer(hostId);
    });
    conn.on('data', (data) => {
      if (data && data.type === 'PEER_LIST' && Array.isArray(data.peers)) {
        data.peers.forEach(id => {
          // Ikki tomonlama qo'ng'iroq bo'lmasligi uchun faqat ID kichigi chaqiradi
          if (id !== p.id && !peers[id] && p.id < id) callRemotePeer(id);
        });
      }
    });
    conn.on('close', () => {
      setToast("Asosiy stansiya uzildi. Qayta ulanilmoqda...");
      setTimeout(() => { if (isConnected) { Object.keys(peers).forEach(removePeer); tryConnectAsHost(hostId); } }, 1200);
    });
  });
  p.on('error', (err) => { console.error(err); setToast("Ulanishda xatolik yuz berdi."); });
}

function setupPeerListeners(p) {
  p.on('connection', (conn) => {
    if (!conn.peer.startsWith(roomKey)) { conn.close(); return; }
    conn.on('open', () => {
      peers[conn.peer] = peers[conn.peer] || {};
      peers[conn.peer].conn = conn;
      updatePeerCount();
      if (isHost) broadcastPeerList();
    });
    conn.on('close', () => { removePeer(conn.peer); if (isHost) broadcastPeerList(); });
  });
  p.on('call', (call) => {
    if (!call.peer.startsWith(roomKey)) { call.close(); return; }
    call.answer(processedStream);
    handleMediaCall(call);
  });
}

function callRemotePeer(id) {
  if (!peer || !processedStream) return;
  if (peers[id] && peers[id].call) return;
  handleMediaCall(peer.call(id, processedStream));
}

function handleMediaCall(call) {
  const id = call.peer;
  peers[id] = peers[id] || {};
  peers[id].call = call;
  updatePeerCount();
  call.on('stream', (s) => attachRemoteAudio(id, s));
  call.on('close', () => removePeer(id));
  call.on('error', () => removePeer(id));
}

function attachRemoteAudio(id, stream) {
  let el = $(`audio-${id}`);
  if (!el) {
    el = document.createElement('audio');
    el.id = `audio-${id}`;
    el.autoplay = true;
    el.playsInline = true;
    el.muted = true; // ovoz GainNode orqali chiqadi
    $('remote-audios').appendChild(el);
  }
  el.srcObject = stream;
  el.play().catch(() => {});

  try {
    ensureAudioContext();
    const src = audioContext.createMediaStreamSource(stream);
    const gain = audioContext.createGain();
    gain.gain.value = boostLevel;
    remoteGains[id] = gain;
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 32;
    src.connect(gain); gain.connect(analyser); gain.connect(audioContext.destination);

    const data = new Uint8Array(analyser.frequencyBinCount);
    let wasRx = false;
    clearInterval(rxTimers[id]);
    rxTimers[id] = setInterval(() => {
      if (!peers[id]) {
        clearInterval(rxTimers[id]);
        delete remoteGains[id];
        if (wasRx) { activeIncomingCount = Math.max(0, activeIncomingCount - 1); updateRxState(); }
        return;
      }
      analyser.getByteFrequencyData(data);
      const speaking = data.reduce((a, b) => a + b, 0) / data.length > 10;
      if (speaking && !wasRx) { wasRx = true; activeIncomingCount++; updateRxState(); }
      else if (!speaking && wasRx) {
        wasRx = false;
        activeIncomingCount = Math.max(0, activeIncomingCount - 1);
        updateRxState();
        if (activeIncomingCount === 0 && !isTransmitting) playSquelchTail();
      }
    }, 120);
  } catch (e) { el.muted = false; }
}

function broadcastPeerList() {
  const ids = Object.keys(peers);
  ids.forEach(id => {
    const c = peers[id].conn;
    if (c && c.open) c.send({ type: 'PEER_LIST', peers: ids });
  });
  updatePeerCount();
}

function removePeer(id) {
  const el = $(`audio-${id}`);
  if (el) el.remove();
  clearInterval(rxTimers[id]);
  delete peers[id];
  delete remoteGains[id];
  updatePeerCount();
}

function updatePeerCount() {
  const count = Object.keys(peers).length;
  peerCountEl.textContent = isConnected ? count + 1 : 0;
  if (isConnected && !isTransmitting && activeIncomingCount === 0) {
    lcdStatus.textContent = count > 0 ? "HIMOYALANGAN ALOQA O'RNATILDI" : "YOPIQ KANAL • KUTILMOQDA";
  }
}

function onConnectedUI(role) {
  connectBtn.disabled = false;
  connectBtn.textContent = "UZISH";
  connectBtn.classList.add('off');
  channelInput.disabled = true;
  passwordInput.disabled = true;
  lcdLock.classList.remove('hidden');
  connBadge.textContent = "SHIFRLANGAN";
  roleBadge.textContent = role;
  updateSignalBars(4);
  updatePeerCount();
  playRogerBeep();
}

function disconnectRadio() {
  stopTransmitting(true);
  isConnected = false; isHost = false; activeIncomingCount = 0;
  Object.keys(peers).forEach(removePeer);
  cleanupPeer();
  connectBtn.disabled = false;
  connectBtn.textContent = "ULANISH";
  connectBtn.classList.remove('off');
  channelInput.disabled = false;
  passwordInput.disabled = false;
  lcdLock.classList.add('hidden');
  connBadge.textContent = "OFLAYN";
  roleBadge.textContent = "KUTISH";
  peerCountEl.textContent = "0";
  lcdStatus.textContent = "ALOQA UZILDI";
  updateSignalBars(0);
  updateRxState();
  setToast("Kanaldan uzildingiz.");
}

function cleanupPeer() {
  if (peer) { try { peer.destroy(); } catch (e) {} peer = null; }
  hostConn = null;
}

// ---------- PTT ----------
async function startTransmitting() {
  if (isTransmitting) return;
  if (!isConnected && !isLoopbackTest) { setToast("Avval ULANISH yoki TEST tugmasini bosing!"); return; }
  if (!(await initMicrophone())) return;

  isTransmitting = true;
  setMicrophoneEnabled(true);
  playTxStartBeep();
  pttBtn.classList.add('transmitting');
  pttBtn.classList.remove('receiving');
  pttMain.textContent = "GAPIRING (EFIRDA)";
  pttSub.textContent = "TRANSMITTING...";
  ledTx.classList.add('led-red');
  lcdStatus.textContent = isLoopbackTest ? "TEST: O'ZINGIZNI ESHITING" : "UZATILMOQDA (TX)...";
  vuLabel.textContent = "TX";
  if (navigator.vibrate) navigator.vibrate(35);
}

function stopTransmitting(silent = false) {
  if (!isTransmitting) return;
  if (isMicLocked && !silent) return;
  isTransmitting = false;
  setMicrophoneEnabled(false);
  if (!silent) { playRogerBeep(); if (navigator.vibrate) navigator.vibrate([20, 30, 20]); }
  pttBtn.classList.remove('transmitting');
  pttMain.textContent = "BOSIB GAPIRING";
  pttSub.textContent = "PUSH TO TALK";
  ledTx.classList.remove('led-red');
  vuLabel.textContent = "MIC";
  if (isLoopbackTest) lcdStatus.textContent = "TEST REJIMI FAOL";
  else if (isConnected) updatePeerCount();
  updateRxState();
}

function updateRxState() {
  if (isTransmitting) return;
  if (activeIncomingCount > 0) {
    ledRx.classList.add('led-green');
    pttBtn.classList.add('receiving');
    pttMain.textContent = "TINGLANMOQDA...";
    pttSub.textContent = "RECEIVING (RX)";
    lcdStatus.textContent = "KIRUVCHI OVOZ (RX)...";
    vuLabel.textContent = "RX";
  } else {
    ledRx.classList.remove('led-green');
    pttBtn.classList.remove('receiving');
    pttMain.textContent = "BOSIB GAPIRING";
    pttSub.textContent = "PUSH TO TALK";
    vuLabel.textContent = "MIC";
    if (isConnected) updatePeerCount();
  }
}

function pttDown(e) {
  e.preventDefault();
  if (isMicLocked) toggleMicLock(); else startTransmitting();
}
function pttUp(e) { e.preventDefault(); stopTransmitting(); }

pttBtn.addEventListener('touchstart', pttDown, { passive: false });
pttBtn.addEventListener('touchend', pttUp, { passive: false });
pttBtn.addEventListener('touchcancel', pttUp, { passive: false });
pttBtn.addEventListener('mousedown', (e) => { if (e.button === 0) pttDown(e); });
window.addEventListener('mouseup', () => { if (isTransmitting && !isMicLocked) stopTransmitting(); });
pttBtn.addEventListener('contextmenu', (e) => e.preventDefault());

async function toggleMicLock() {
  if (!isConnected && !isLoopbackTest) { setToast("Avval ULANISH yoki TEST tugmasini bosing!"); return; }
  const btn = $('lock-btn'), txt = $('lock-btn-text');
  if (!isMicLocked) {
    isMicLocked = true;
    btn.classList.add('active');
    btn.firstElementChild.textContent = '🔒';
    txt.textContent = 'QULFLANGAN';
    await startTransmitting();
    setToast("Mikrofon qulflandi. Ochish uchun yana bosing.");
  } else {
    isMicLocked = false;
    btn.classList.remove('active');
    btn.firstElementChild.textContent = '🔓';
    txt.textContent = 'QULFLASH';
    stopTransmitting();
    setToast("Mikrofon qulfi ochildi.");
  }
}

async function toggleLoopbackTest() {
  const btn = $('test-btn'), txt = $('test-btn-text');
  if (!isLoopbackTest) {
    if (isConnected) disconnectRadio();
    if (!(await initMicrophone())) return;
    isLoopbackTest = true;
    btn.classList.add('active');
    txt.textContent = 'TEST FAOL';
    lcdStatus.textContent = "TEST REJIMI FAOL";
    connBadge.textContent = "TEST";
    updateSignalBars(4);
    loopbackAudioEl = document.createElement('audio');
    loopbackAudioEl.srcObject = processedStream;
    loopbackAudioEl.play().catch(() => {});
    setToast("TEST: PTT ni bosib gapiring, o'z ovozingiz eshitiladi.");
  } else {
    if (isMicLocked) await toggleMicLock();
    stopTransmitting(true);
    isLoopbackTest = false;
    btn.classList.remove('active');
    txt.textContent = 'TEST';
    lcdStatus.textContent = "KANAL TANLANG VA ULANING";
    connBadge.textContent = "OFLAYN";
    updateSignalBars(0);
    if (loopbackAudioEl) { loopbackAudioEl.pause(); loopbackAudioEl.srcObject = null; loopbackAudioEl = null; }
    setToast("Test rejimi o'chirildi.");
  }
}

// Ovoz kuchaytirgich: 2.2 → 1.0 → 1.5 → 2.2 (mikrofon va kiruvchi ovoz)
function toggleAudioBoost() {
  boostLevel = boostLevel === 2.2 ? 1.0 : boostLevel === 1.0 ? 1.5 : 2.2;
  $('boost-btn-text').textContent = `OVOZ ${boostLevel.toFixed(1)}X`;
  setToast(`Ovoz kuchaytirgich: ${boostLevel.toFixed(1)}x`);
  if (micGainNode) micGainNode.gain.value = boostLevel;
  Object.values(remoteGains).forEach(g => { g.gain.value = boostLevel; });
}

// ---------- Ekran o'chmasligi ----------
async function requestWakeLock() {
  try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
}
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && isConnected) requestWakeLock();
});


// ---------- Ishlab chiquvchi ruxsati (birinchi kirishda) ----------
const GATE_HASH = "8bbaa91a3a8cbc6da326ff81b68acf3826ddbfd52839e7435f4b83d67d951653"; // SHA-256("alisa")
const GATE_KEY = "ratsiya_access_ok";

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function openGate(ok) { $('gate').classList.toggle('hidden', ok); }
async function checkGate() {
  const word = $('gate-input').value.trim().toLowerCase();
  if (!word) return;
  if (await sha256Hex(word) === GATE_HASH) {
    try { localStorage.setItem(GATE_KEY, '1'); } catch (e) {}
    openGate(true);
  } else {
    $('gate-error').textContent = "Noto'g'ri so'z. Qayta urinib ko'ring.";
    $('gate-input').value = '';
  }
}
$('gate-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') checkGate(); });
(function initGate() {
  let ok = false;
  try { ok = localStorage.getItem(GATE_KEY) === '1'; } catch (e) {}
  openGate(ok);
})();
